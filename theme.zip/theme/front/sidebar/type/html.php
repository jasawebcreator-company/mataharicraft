<?= $data->data ?>
